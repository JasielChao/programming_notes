# fancybox v3.5 - Initialize with JavaScript / Simple filter

A Pen created on CodePen.io. Original URL: [https://codepen.io/fancyapps/pen/NLQJQp](https://codepen.io/fancyapps/pen/NLQJQp).

