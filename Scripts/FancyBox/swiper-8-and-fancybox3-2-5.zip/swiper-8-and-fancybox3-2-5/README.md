# Swiper 8 and fancybox3.2.5

A Pen created on CodePen.io. Original URL: [https://codepen.io/ezra_siton/pen/MQgYxV](https://codepen.io/ezra_siton/pen/MQgYxV).

