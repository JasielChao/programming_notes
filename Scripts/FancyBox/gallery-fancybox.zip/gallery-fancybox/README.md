# Gallery Fancybox

A Pen created on CodePen.io. Original URL: [https://codepen.io/soumitraghosh99/pen/ExdxzQg](https://codepen.io/soumitraghosh99/pen/ExdxzQg).

