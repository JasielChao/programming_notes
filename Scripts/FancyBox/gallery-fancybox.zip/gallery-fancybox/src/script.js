Fancybox.bind("[data-fancybox]", {
    // Your custom options
});