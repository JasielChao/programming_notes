# Tabs

A Pen created on CodePen.io. Original URL: [https://codepen.io/Panni98/pen/vYPJjmK](https://codepen.io/Panni98/pen/vYPJjmK).

This is a tab switch made with bootstrap and jquery. 
it will show the first tab on default when loaded and saves the last clicked tab to local storage so when the page is refreshed it shows the last tab clicked.
this is the first project I did with jquery;