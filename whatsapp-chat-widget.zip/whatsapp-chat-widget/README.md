# Whatsapp Chat Widget

A Pen created on CodePen.io. Original URL: [https://codepen.io/ceesjuh97/pen/WNbQBJE](https://codepen.io/ceesjuh97/pen/WNbQBJE).

Multiple Whatsapp Chat Widget, with HTML, CSS, Javascript. Use Font Awesome and jQuery. This widget created by Dunia Blanter www.idblanter.com and the owner Rhinokage Rio.