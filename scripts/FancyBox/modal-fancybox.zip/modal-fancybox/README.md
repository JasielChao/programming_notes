# Modal Fancybox

A Pen created on CodePen.io. Original URL: [https://codepen.io/sdev01/pen/bGdpgqz](https://codepen.io/sdev01/pen/bGdpgqz).

