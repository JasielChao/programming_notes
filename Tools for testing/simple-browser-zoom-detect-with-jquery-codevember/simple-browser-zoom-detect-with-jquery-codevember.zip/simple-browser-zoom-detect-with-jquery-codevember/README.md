# Simple browser zoom detect with jquery #codevember

A Pen created on CodePen.io. Original URL: [https://codepen.io/reinis/pen/RooGOE](https://codepen.io/reinis/pen/RooGOE).

Just press ctrl and scroll to zoom in or out. It will show zoom level and change some body background color.