# Side Menu

A Pen created on CodePen.io. Original URL: [https://codepen.io/LYkN/pen/LYEMZwY](https://codepen.io/LYkN/pen/LYEMZwY).

Vertical side menu, pure CSS3 and HTML